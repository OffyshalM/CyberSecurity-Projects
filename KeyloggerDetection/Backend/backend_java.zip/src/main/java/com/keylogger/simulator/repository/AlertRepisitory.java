package com.keylogger.simulator.repository;
import com.keylogger.simulator.model.Alert;
import org.springframework.stereotype.Repository;
import java.util.Optional;
    

@Repository 

public interface AlertRepisitory extends org.springframework.data.jpa.repository.JpaRepository<Alert, Long> {

 Optional <Alert>  findByDeviceIdAndTimestamp(String deviceId, String timestamp);
 Optional <Alert>  findByDeviceIdAndProcessNameAndTimestamp(String deviceId, String processName, String timestamp);
 Optional <Alert>  findByAnomalyScore(Double anomalyScore);
 Optional <Alert>   findBySeverity(String severity);
 Optional <Alert>   findByEventType(String eventType);

}