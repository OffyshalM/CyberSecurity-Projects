package com.keylogger.simulator.service;
import com.keylogger.simulator.repository.AlertRepisitory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.keylogger.simulator.model.Alert;

@Service
public class AlertService {
    

    @Autowired
    private AlertRepisitory alertRepisitory;

    public Alert saveAlert(Alert alert) {

        return alertRepisitory.save(alert);
    }


}
