package com.keylogger.simulator.controller;

import com.keylogger.simulator.model.Alert;
import com.keylogger.simulator.repository.AlertRepisitory;
import com.keylogger.simulator.service.AlertService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/alerts")
@CrossOrigin(origins = "*")
public class AlertController {

    @Autowired 
    private AlertRepisitory alertRepository;
    
    @Autowired
    private AlertService alertService;

    @PostMapping("/save")
    public ResponseEntity<String> saveAlerts(@RequestBody List<Alert> alerts) {
        for (Alert alert : alerts) {
            alertService.saveAlert(alert);
        }
        return ResponseEntity.ok("Successfully saved " + alerts.size() + " alerts to the database!");
    }

    @GetMapping ("/all")

    public ResponseEntity<List<Alert>> getAlerts(){
        List <Alert> alerts = alertRepository.findAll();
        return ResponseEntity.ok(alerts);
    }
}