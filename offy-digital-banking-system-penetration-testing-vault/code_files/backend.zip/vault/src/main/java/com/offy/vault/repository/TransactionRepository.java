package com.offy.vault.repository;

import com.offy.vault.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    List<Transaction> findBySenderAccountNumber(String senderAccountNumber);

    List<Transaction> findByReceiverAccountNumber(String receiverAccountNumber);

    List<Transaction> findByReceiverAccountNumberOrSenderAccountNumber(String receiverAccountNumber, String senderAccountNumber);
}