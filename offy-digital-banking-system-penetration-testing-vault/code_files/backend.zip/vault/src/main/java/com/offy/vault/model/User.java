package com.offy.vault.model;

import jakarta.persistence.*;
import lombok.Data;
import java.math.BigDecimal;

@Entity
@Table(name = "users")
@Data 
public class User {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    
    @Column(unique = true, nullable = false)
    private String username;

    @Column(name = "password_hash", nullable = false)
    private String passwordHash;
    
    @Column(name = "account_number", unique = true, nullable = false)
    private String accountNumber;
    
    private BigDecimal balance;
    
    @Column(name = "role", nullable = false)
    private String role;
}