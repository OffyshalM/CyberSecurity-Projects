package com.offy.vault.controller;

import com.offy.vault.model.Account;
import com.offy.vault.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/accounts")
@CrossOrigin(origins = "*")
public class AccountController {

    @Autowired
    private AccountRepository accountRepository;

    @GetMapping
    public ResponseEntity<?> getAllAccounts() {
        return ResponseEntity.ok(accountRepository.findAll());
    }
    /**
     * VULNERABLE ENDPOINT: IDOR (Insecure Direct Object Reference)
     * Anyone can change the {id} path parameter to view any account data row.
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getAccountDetails(@PathVariable Long id) {

        // EXPLOIT VECTOR: We are completely skipping authorization checks here!
        // We do not verify if the current user session matches the account owner.
        Optional<Account> accountOptional = accountRepository.findById(id);

        if (accountOptional.isPresent()) {
            return ResponseEntity.ok(accountOptional.get());
        }

        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(Map.of("message", "Account file not found in the ledger database."));
    }
}