package com.offy.vault.repository;

import com.offy.vault.model.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface AccountRepository extends JpaRepository<Account, Long> {
    // Custom query to optionally look up an account by its account number string
    Optional<Account> findByAccountNumber(String accountNumber);
}