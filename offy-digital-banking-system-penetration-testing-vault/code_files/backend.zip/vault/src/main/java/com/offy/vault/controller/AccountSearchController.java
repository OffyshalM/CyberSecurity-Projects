package com.offy.vault.controller; 
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
public class AccountSearchController {

    @PersistenceContext
    private EntityManager entityManager;

    // VULNERABLE ENDPOINT: Direct string concatenation allows SQL Injection
    @GetMapping("/api/users/search")
    public ResponseEntity<?> searchUsersByName(@RequestParam("username") String username) {
        try {
            // This glues the user's input directly into the SQL string
            String rawQuery = "SELECT * FROM users WHERE username = '" + username + "'";
            
            Query query = entityManager.createNativeQuery(rawQuery);
            List<?> results = query.getResultList();
            
            return ResponseEntity.ok(results);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Database error: " + e.getMessage());
        }
    }
}