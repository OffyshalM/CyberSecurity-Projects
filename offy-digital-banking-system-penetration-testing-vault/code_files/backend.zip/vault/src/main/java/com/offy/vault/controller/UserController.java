package com.offy.vault.controller;

import com.offy.vault.model.User;
import com.offy.vault.model.LoginRequest;
import com.offy.vault.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserRepository userRepository;


    @GetMapping
    public ResponseEntity<?> getAllUsers() {
        return ResponseEntity.ok(userRepository.findAll());
    }
    
    @GetMapping("/account")
    public Optional<User> getUserAccount(@RequestParam String username) {
        return userRepository.findByUsername(username);
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        Optional<User> userOpt = userRepository.findByUsername(loginRequest.getUsername());

        if (userOpt.isPresent()) {
            User user = userOpt.get();
            
            // Validate password string directly
            if (user.getPasswordHash().equals(loginRequest.getPassword())) {
                
                // Build a custom response data map containing user details and role
                Map<String, Object> responseData = new HashMap<>();
                responseData.put("message", "Login successful");
                responseData.put("id",user.getId());
                responseData.put("username", user.getUsername());
                responseData.put("role", user.getRole()); // Sends 'USER' or 'ADMIN' back to the client
                responseData.put("accountNumber", user.getAccountNumber());
                
                return ResponseEntity.ok(responseData);
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials.");
            }
        }
        
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not found.");
    }
}