package com.offy.vault.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.offy.vault.model.Account;
import com.offy.vault.model.Transaction;
import com.offy.vault.repository.AccountRepository;
import com.offy.vault.repository.TransactionRepository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/api/transactions/transfer")
@CrossOrigin(origins = "*")


public class TransactionController {
    

    @Autowired 
    private TransactionRepository transactionRepository;

    @GetMapping("/{id}")
    public ResponseEntity<?> getTransactionById(@PathVariable Long id){

        Optional<Transaction> transactionOptional = transactionRepository.findById(id);

        if (transactionOptional.isPresent()){
            return ResponseEntity.ok(transactionOptional.get());
        } else {
            return ResponseEntity.notFound().build();

        }
        
    }

    @Autowired AccountRepository accountRepository;
    @PostMapping("/")
    public ResponseEntity<?> createTransactionEntity (@RequestBody Transaction transaction){

        if(transaction.getSenderAccountNumber() == null || transaction.getReceiverAccountNumber() == null){
            return ResponseEntity.badRequest().body("Sender and Receiver account numbers must be provided.");
        }

        // if (transaction.getAmount() == null || transaction.getAmount().compareTo(java.math.BigDecimal.ZERO) <= 0) {
        //     return ResponseEntity.badRequest().body("Transaction amount must be greater than zero.");
        // }


    Optional<Account> senderOption = accountRepository.findByAccountNumber(transaction.getSenderAccountNumber());
    Optional<Account> receiverOption = accountRepository.findByAccountNumber(transaction.getReceiverAccountNumber());

    if (!senderOption.isPresent() && !receiverOption.isPresent()){
        return ResponseEntity.badRequest().body("Sender and Receiver accounts do not exist.");
    }   Account senderAccount = senderOption.get();
        Account  receiverAccount = receiverOption.get();

    BigDecimal amount = transaction.getAmount();


    BigDecimal senderNewBalance = senderAccount.getBalance().subtract(amount);
    BigDecimal receiverNewBalance = receiverAccount.getBalance().add(amount);

    senderAccount.setBalance(senderNewBalance);
    receiverAccount.setBalance(receiverNewBalance); 

    accountRepository.save(senderAccount);
    accountRepository.save(receiverAccount);


    Transaction savedTransaction = transactionRepository.save(transaction);

        return ResponseEntity.ok(savedTransaction);
    }


    @GetMapping("/history/{accountNumber}")

    public ResponseEntity<?> getTransactionHistory(@PathVariable String accountNumber){

        List <Transaction> transactionHistory = transactionRepository.findByReceiverAccountNumberOrSenderAccountNumber(accountNumber, accountNumber);

        if (transactionHistory.isEmpty()){
            return ResponseEntity.ok("No tranactions found for account number: " + accountNumber);
        }

        return ResponseEntity.ok(transactionHistory);


    }
}
