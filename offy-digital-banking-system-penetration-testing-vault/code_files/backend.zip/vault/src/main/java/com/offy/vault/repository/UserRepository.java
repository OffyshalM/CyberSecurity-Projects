package com.offy.vault.repository;

import com.offy.vault.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
    // This custom finder will allow us to look up users by their username for the login mechanics
    Optional<User> findByUsername(String username);
}