import React, { useState, useRef, useEffect } from "react";
import { Plus, Bell, User, Settings, LogOut } from "lucide-react";

export default function AdminNavbar({ adminName }) {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);

  // Fallback string configurations if database content hasn't completed loading yet
  const displayedName = adminName || localStorage.getItem("username") || "Okunrobo Moses Emmanuel";

  // Close dropdown if clicked outside
  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleLogout = () => {
    localStorage.clear();
    window.location.href = "/admin/login";
  };

  return (
    <header className="sticky top-0 right-0 left-0 h-20 bg-white/90 backdrop-blur-md border-b border-slate-100 flex items-center justify-between px-6 md:px-8 z-30 w-full">
      
      {/* Quick Actions Panel */}
      <div>
        <button className="flex items-center gap-2 bg-[#f0f3ff] hover:bg-indigo-50 text-vault-neon font-bold text-xs px-4 py-2.5 rounded-xl transition-all shadow-sm">
          <Plus className="h-4 w-4 stroke-[2.5]" />
          <span>Manage Settings</span>
        </button>
      </div>

      {/* Profile & Notifications Group */}
      <div className="flex items-center gap-4 relative">
        {/* Notification Bell */}
        <button className="relative p-2.5 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-xl transition-all">
          <Bell className="h-5 w-5 stroke-[2.2]" />
          <span className="absolute top-2 right-2 h-2 w-2 bg-pink-500 rounded-full border-2 border-white"></span>
        </button>

        {/* Admin Avatar Dropdown Container */}
        <div className="relative" ref={dropdownRef}>
          <button 
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className="flex items-center gap-2.5 cursor-pointer focus:outline-none"
          >
            <div className="h-10 w-10 bg-amber-100 hover:bg-amber-200 active:scale-95 rounded-xl border border-amber-200 flex items-center justify-center text-lg transition-all shadow-sm">
              👊
            </div>
          </button>

          {/* Dynamic Dropdown Panel */}
          {dropdownOpen && (
            <div className="absolute right-0 mt-3 w-56 bg-white rounded-2xl border border-slate-100 shadow-xl py-2 z-50 animate-fadeIn">
              {/* Header Info */}
              <div className="px-4 py-3 border-b border-slate-50">
                <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Logged in as</p>
                <p className="text-xs font-extrabold text-slate-800 truncate mt-0.5">{displayedName}</p>
              </div>

              {/* Action Buttons */}
              <div className="p-1 space-y-0.5">
                <button className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-600 hover:text-[#4f46e5] hover:bg-indigo-50/50 rounded-lg transition-all">
                  <User className="h-4 w-4" />
                  <span>Account Settings</span>
                </button>
                <button className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-600 hover:text-[#4f46e5] hover:bg-indigo-50/50 rounded-lg transition-all">
                  <Settings className="h-4 w-4" />
                  <span>System Preferences</span>
                </button>
              </div>

              {/* Logout Area */}
              <div className="p-1 border-t border-slate-50 mt-1">
                <button 
                  onClick={handleLogout}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-bold text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                >
                  <LogOut className="h-4 w-4" />
                  <span>Log Out</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}