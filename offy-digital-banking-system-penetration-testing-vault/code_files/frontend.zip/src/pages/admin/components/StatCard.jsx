import React from "react";

export default function StatCard({ title, value, icon: Icon, iconBg, iconColor, footerText, footerTrend, isLiveIndicator }) {
  return (
    <div className="bg-white rounded-2xl border border-slate-100 p-5 flex flex-col justify-between shadow-sm hover:shadow-md transition-shadow">
      
      {/* Upper Content */}
      <div className="flex items-start gap-4">
        {/* Icon Plate */}
        <div className={`h-12 w-12 rounded-xl flex items-center justify-center ${iconBg} ${iconColor}`}>
          <Icon className="h-5 w-5 stroke-[2.2]" />
        </div>

        {/* Data points */}
        <div className="space-y-1">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">{title}</span>
          <h2 className="text-2xl font-extrabold text-slate-800 tracking-tight">{value}</h2>
        </div>
      </div>

      {/* Divider */}
      <div className="border-t border-slate-50 my-4"></div>

      {/* Footer Metrics */}
      <div className="flex items-center gap-1.5 text-xs font-semibold">
        {isLiveIndicator ? (
          <>
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-emerald-600">{footerText}</span>
          </>
        ) : (
          <>
            {footerTrend && (
              <span className={footerTrend.startsWith("+") ? "text-emerald-500" : "text-rose-500"}>
                {footerTrend}
              </span>
            )}
            <span className="text-slate-400">{footerText}</span>
          </>
        )}
      </div>
    </div>
  );
}