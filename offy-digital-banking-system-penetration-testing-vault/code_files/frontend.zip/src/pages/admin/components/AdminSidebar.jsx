import React, { useState } from "react";
import { 
  LayoutDashboard, 
  Users, 
  GitBranch, 
  CreditCard, 
  History, 
  Settings, 
  LogOut, 
  ChevronDown, 
  MessageSquare 
} from "lucide-react";

export default function AdminSidebar() {
  const [activeMenu, setActiveMenu] = useState("Dashboard");
  const [openDropdowns, setOpenDropdowns] = useState({
    customers: false,
    branch: false,
    accountType: false,
    history: false,
    settings: false,
  });

  const toggleDropdown = (menu) => {
    setOpenDropdowns((prev) => ({ ...prev, [menu]: !prev[menu] }));
  };

  const menuItems = [
    { name: "Dashboard", icon: LayoutDashboard, hasDropdown: false },
    { name: "Customers", icon: Users, hasDropdown: true, key: "customers" },
    { name: "Branch", icon: GitBranch, hasDropdown: true, key: "branch" },
    { name: "Account Type", icon: CreditCard, hasDropdown: true, key: "accountType" },
    { name: "History", icon: History, hasDropdown: true, key: "history" },
    { name: "Settings", icon: Settings, hasDropdown: true, key: "settings" },
  ];

  return (
    <aside className="fixed inset-y-0 left-0 z-20 w-64 bg-white border-r border-slate-100 flex flex-col justify-between py-6">
      <div className="space-y-6">
        {/* Brand Logo Placeholder */}
        <div className="px-6 flex items-center gap-2">
          <div className="h-8 w-8 bg-vault-neon rounded-lg flex items-center justify-center text-white font-bold text-sm">V</div>
          <span className="font-bold text-slate-800 text-lg tracking-tight"> MyAdmin Panel</span>
        </div>

        {/* Navigation Menu */}
        <nav className="px-3 space-y-1">
          {menuItems.map((item) => {
            const isSelected = activeMenu === item.name;
            const Icon = item.icon;

            return (
              <div key={item.name} className="w-full">
                {item.hasDropdown ? (
                  <button
                    onClick={() => toggleDropdown(item.key)}
                    className="w-full flex items-center justify-between px-4 py-3 rounded-xl text-xs font-semibold transition-all text-slate-500 hover:bg-slate-50 hover:text-slate-800"
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="h-4 w-4 stroke-[2.5]" />
                      <span>{item.name}</span>
                    </div>
                    <ChevronDown className={`h-3.5 w-3.5 transition-transform duration-200 ${openDropdowns[item.key] ? "rotate-180" : ""}`} />
                  </button>
                ) : (
                  <button
                    onClick={() => setActiveMenu(item.name)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold transition-all ${
                      isSelected 
                        ? "bg-[#eef2ff] text-vault-neon" 
                        : "text-slate-500 hover:bg-slate-50 hover:text-slate-800"
                    }`}
                  >
                    <Icon className="h-4 w-4 stroke-[2.5]" />
                    <span>{item.name}</span>
                  </button>
                )}

                {/* Submenu Drawer */}
                {item.hasDropdown && openDropdowns[item.key] && (
                  <div className="pl-11 pr-4 py-1 space-y-1">
                    <button className="w-full text-left py-2 px-2 text-[11px] font-semibold text-slate-400 hover:text-slate-700">View All</button>
                    <button className="w-full text-left py-2 px-2 text-[11px] font-semibold text-slate-400 hover:text-slate-700">Manage</button>
                  </div>
                )}
              </div>
            );
          })}

          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold text-slate-500 hover:bg-red-50 hover:text-red-600 transition-all">
            <LogOut className="h-4 w-4 stroke-[2.5]" />
            <span>Logout</span>
          </button>
        </nav>
      </div>

      {/* Developer Footer Contact */}
      <div className="px-6">
        <a 
          href="https://wa.me/2348133214373" 
          target="_blank" 
          rel="noreferrer"
          className="flex items-center gap-2.5 text-xs font-semibold text-slate-400 hover:text-[#25d366] transition-colors"
        >
          <MessageSquare className="h-4 w-4" />
          <span>Contact Developer</span>
        </a>
      </div>
    </aside>
  );
}