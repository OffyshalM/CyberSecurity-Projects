import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Shield, User, Lock, AlertCircle, Loader2 } from "lucide-react";
import axios from "axios";

export default function AdminLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleAdminSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      // 1. Query the live Spring Boot backend MySQL data rows
      const API_BASE = `${window.location.origin}/api`;
      const response = await axios.post(`${API_BASE}/users/login`, {
        username: username,
        password: password,
      });

      // 2. Extract the authenticated user's role payload
      const userRole = response.data.role; 

      // 3. Strict Check: Only grant entry if they have administrative roles
      if (userRole !== "ADMIN" && userRole !== "SUPER_ADMIN") {
        setError("Access Denied: Regular user accounts are not authorized to access this administrative portal.");
        setLoading(false);
        return;
      }

      // 4. Success: Set up administrative session attributes
      localStorage.setItem("adminUser", response.data.username || username);
      localStorage.setItem("adminRole", userRole);
      localStorage.setItem("accountNumber", response.data.accountNumber);
      
      // Route immediately into the administrative panel
      navigate("/admin/dashboard");
    } catch (err) {
      if (err.response) {
        setError(err.response.data.message || "Invalid administrative credentials.");
      } else {
        setError("Could not connect to the authentication server. Ensure Spring Boot is running.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-[#0A0F1D] font-sans text-slate-100">
      
      {/* LEFT PANE: Premium Dark Corporate Branding Sidebar (Hidden on Mobile) */}
      <div className="hidden md:flex w-5/12 flex-col justify-between bg-gradient-to-b from-[#0D1527] to-[#070B15] p-12 border-r border-slate-800/50">
        <div className="flex items-center gap-3">
          {/* Custom Teal Accent Branding Border */}
          <div className="bg-teal-500/10 border border-teal-500/30 p-2 rounded-xl">
            <Shield className="h-6 w-6 text-teal-400" />
          </div>
          <span className="text-lg font-bold tracking-tight text-white">Protected System Terminal</span>
        </div>

        <div className="max-w-sm space-y-6">
          <h1 className="text-3xl font-extrabold tracking-tight text-white leading-tight">
            System Administration Interface
          </h1>
          <p className="text-slate-400 text-sm leading-relaxed">
           Protected Node Environment. Prohibited interaction or configuration overrides will trigger security alerts. Following system safety standards, every session state, authentication token, and endpoint interaction is sealed in a cryptographic ledger for continuous audit inspection.
          </p>
          
          <div className="pt-4 space-y-3 border-t border-slate-800/80 text-xs text-slate-400">
            <div className="flex items-center justify-between">
              <span>Central Ledger Array:</span>
              <span className="text-teal-400 font-semibold flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-teal-400 animate-pulse" /> Active
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span>TLS Session Layer:</span>
              <span className="text-slate-400 font-medium">256-Bit TLS 1.3 Encryption</span>
            </div>
          </div>
        </div>

        <div className="text-xs text-slate-500">
          Provisioned Console Signature: <span className="font-mono text-slate-400">NODE-AUTH-X89</span>
        </div>
      </div>

      {/* RIGHT PANE: Modern Solid Input Card Panel */}
      <div className="w-full md:w-7/12 flex items-center justify-center bg-[#F8FAFC] p-6 sm:p-12 text-slate-900">
        <div className="w-full max-w-md bg-white p-8 sm:p-10 rounded-2xl shadow-xl shadow-slate-200/60 border border-slate-100">
          
          <div className="mb-6">
            {/* Custom Teal Styling Node Accent */}
            <div className="inline-flex items-center gap-2 bg-teal-50 border border-teal-200 px-3 py-1 rounded-full text-xs font-semibold text-teal-700 mb-3">
              <span className="h-1.5 w-1.5 rounded-full bg-teal-500" />  Encrypted Connection
            </div>
            <h2 className="text-2xl font-extrabold text-slate-950 tracking-tight">
              Admin Login
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Enter your credentials to manage the core banking system.
            </p>
          </div>

          {/* Error Banner Notification Element */}
          {error && (
            <div className="mb-5 flex items-start gap-2.5 rounded-xl bg-red-50 border border-red-200 p-4 text-xs text-red-700 font-medium leading-relaxed">
              <AlertCircle className="h-4 w-4 flex-shrink-0 text-red-500 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleAdminSubmit} className="space-y-4">
            <div>
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                Username
              </label>
              <div className="relative">
                <User className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. ADMIN-001"
                  className="w-full rounded-xl border border-slate-200 bg-slate-50/50 py-3 pl-11 pr-4 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:bg-white focus:outline-none transition-all"
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400">
                  Secure Password
                </label>
              </div>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full rounded-xl border border-slate-200 bg-slate-50/50 py-3 pl-11 pr-4 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-500 focus:bg-white focus:outline-none transition-all"
                />

              </div>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <input 
                type="checkbox" 
                id="authorize" 
                className="rounded border-slate-300 text-teal-600 focus:ring-teal-500 h-3.5 w-3.5"
              />
              <label htmlFor="authorize" className="text-xs font-medium text-slate-500 select-none">
                Authorize this device
              </label>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 rounded-xl bg-teal-600 py-3.5 text-xs font-bold text-white shadow-lg shadow-teal-600/20 hover:bg-teal-700 active:scale-[0.99] disabled:opacity-50 transition-all flex items-center justify-center gap-2"
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Sign In"}
            </button>
          </form>

        </div>
      </div>
    </div>
  );
}