import React, { useState, useEffect } from "react";
import { Users, Radio, Wallet, UserPlus, Sliders, Filter, Eye, Trash2 } from "lucide-react";
import AdminSidebar from "./components/AdminSidebar";
import AdminNavbar from "./components/AdminNavbar";
import StatCard from "./components/StatCard";

export default function AdminDashboard() {
  const [combinedData, setCombinedData] = useState([]);
  const [dbAdminName, setDbAdminName] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [metrics, setMetrics] = useState({
    activeNow: 1,
    newOnboarding: 1
  });

  const API_BASE = `${window.location.origin}/api`;

  const fetchAndMergeDatabaseData = async () => {
    setLoading(true);
    setError("");

    try {
      const [accountsResponse, usersResponse] = await Promise.all([
        fetch(`${API_BASE}/accounts`, { method: "GET", headers: { "Content-Type": "application/json" } }),
        fetch(`${API_BASE}/users`, { method: "GET", headers: { "Content-Type": "application/json" } })
      ]);

      if (!accountsResponse.ok || !usersResponse.ok) {
        throw new Error("One or both endpoints returned an invalid response code.");
      }

      const accountsData = await accountsResponse.json();
      const usersData = await usersResponse.json();

      const accountsList = Array.isArray(accountsData) ? accountsData : [];
      const usersList = Array.isArray(usersData) ? usersData : [];

      // Extract the admin name dynamically from the users database list
      const currentUsername = localStorage.getItem("username");
      const foundAdmin = usersList.find(
        (u) => u.role === "ADMIN" || (currentUsername && String(u.username) === String(currentUsername))
      );
      if (foundAdmin) {
        setDbAdminName(foundAdmin.username);
      }

      // Merge accounts with matching user records
      const merged = accountsList.map((account) => {
        const matchingUser = usersList.find(
          (u) => 
            String(u.accountNumber) === String(account.accountNumber) || 
            String(u.id) === String(account.userId)
        );

        return {
          id: account.id,
          accountNumber: account.accountNumber,
          accountHolder: account.accountHolder || (matchingUser ? matchingUser.username : "Unknown Holder"),
          balance: account.balance !== undefined ? Number(account.balance) : (matchingUser ? Number(matchingUser.balance) : 0),
          accountType: account.accountType || "Standard",
          passwordHash: matchingUser ? matchingUser.passwordHash : "No User Link",
          role: matchingUser ? matchingUser.role : "USER"
        };
      });

      // Filter: Keep only standard user records (hide ADMIN role)
      const userActivityOnly = merged.filter((row) => row.role !== "ADMIN");

      setCombinedData(userActivityOnly);
    } catch (err) {
      console.error("Stitching pipeline failure:", err);
      setError("Unable to connect to your Spring Boot backend endpoints. Verify both controllers are up.");
      setCombinedData([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAndMergeDatabaseData();
  }, []);

  // Dynamically calculate total holdings from standard users in the dataset
  const totalUserBalances = combinedData.reduce((sum, row) => sum + row.balance, 0);

  return (
    <div className="flex min-h-screen bg-[#fafbfc] text-slate-800 font-sans" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      <AdminSidebar />

      <div className="flex-1 flex flex-col min-w-0 md:pl-64 min-h-screen overflow-y-auto">
        <AdminNavbar adminName={dbAdminName} />

        <main className="p-6 md:p-8 max-w-7xl w-full mx-auto space-y-8 pt-28 pb-12 z-10 relative">
          
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="space-y-1">
              <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">System Overview</h1>
              <p className="text-xs text-slate-400 font-semibold">Real-time analytics and user management portal.</p>
            </div>
            
            <button className="flex items-center gap-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition-all shadow-sm">
              <Sliders className="h-4 w-4" />
              <span>System Settings</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            <StatCard 
              title="Total Accounts"
              value={combinedData.length} 
              icon={Users}
              iconBg="bg-indigo-50"
              iconColor="text-indigo-600"
              footerText="Live user records"
            />
            <StatCard 
              title="Active Now"
              value={metrics.activeNow}
              icon={Radio}
              iconBg="bg-cyan-50"
              iconColor="text-cyan-600"
              footerText="System Live"
              isLiveIndicator={true}
            />
            <StatCard 
              title="Total User Balance"
              value={`$${totalUserBalances.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
              icon={Wallet}
              iconBg="bg-emerald-50"
              iconColor="text-emerald-600"
              footerTrend=""
              footerText="Combined active holdings"
            />
            <StatCard 
              title="New Onboarding"
              value={metrics.newOnboarding}
              icon={UserPlus}
              iconBg="bg-amber-50"
              iconColor="text-amber-600"
              footerText="Last 24 hours"
            />
          </div>

          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 space-y-4">
            
            <div className="flex items-center justify-between">
              <h3 className="text-base font-extrabold text-slate-800 tracking-tight">Recent User Activity</h3>
              <button className="flex items-center gap-2 border border-slate-200 hover:bg-slate-50 font-bold text-xs text-slate-600 px-3 py-2 rounded-xl transition-all">
                <Filter className="h-3.5 w-3.5 text-slate-400" />
                <span>Filter</span>
              </button>
            </div>

            {error && (
              <div className="text-[11px] bg-red-50 border border-red-200 p-3 rounded-xl font-bold text-red-700">
                Connection Status: {error}
              </div>
            )}

            <div className="overflow-x-auto border border-slate-50 rounded-xl">
              <table className="w-full text-left border-collapse min-w-[950px]">
                <thead>
                  <tr className="bg-[#fcfdfe] border-b border-slate-100 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    <th className="px-6 py-4">Client / Role</th>
                    <th className="px-6 py-4">Account Number</th>
                    <th className="px-6 py-4">Balance / Type</th>
                    <th className="px-6 py-4">Secure Password Key Hash</th>
                    <th className="px-6 py-4 text-right">Operations</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs text-slate-600 font-semibold">
                  {loading ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-12 text-center text-slate-400">
                        Querying database entities...
                      </td>
                    </tr>
                  ) : combinedData.length > 0 ? (
                    combinedData.map((row) => (
                      <tr key={row.id} className="hover:bg-slate-50/40 transition-colors">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="h-8 w-8 rounded-full bg-indigo-50 text-[#4f46e5] flex items-center justify-center text-[11px] font-extrabold">
                              {row.accountHolder ? row.accountHolder.split(" ").map(n => n[0]).join("") : "U"}
                            </div>
                            <div className="flex flex-col">
                              <span className="font-bold text-slate-800">{row.accountHolder}</span>
                              <span className="text-[10px] text-slate-400 mt-0.5 font-bold uppercase tracking-wide">{row.role}</span>
                            </div>
                          </div>
                        </td>
                        
                        <td className="px-6 py-4 text-slate-500 font-mono">
                          {row.accountNumber || "N/A"}
                        </td>

                        <td className="px-6 py-4">
                          <div className="flex flex-col">
                            <span className="text-slate-800 font-bold">${row.balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                            <span className="text-[10px] text-slate-400 font-medium mt-0.5">{row.accountType}</span>
                          </div>
                        </td>

                        <td className="px-6 py-4 font-mono text-[11px] text-slate-400 max-w-[220px] truncate">
                          {row.passwordHash}
                        </td>

                        <td className="px-6 py-4 text-right">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#e8fff3] text-vault-neon border border-[#bbf7d0] mr-4">
                            Verified
                          </span>
                          <div className="inline-flex items-center justify-end gap-2">
                            <button className="p-1.5 border border-slate-100 hover:bg-slate-50 text-slate-400 hover:text-[#4f46e5] rounded-lg transition-colors">
                              <Eye className="h-4 w-4" />
                            </button>
                            <button className="p-1.5 border border-slate-100 hover:bg-slate-50 text-slate-400 hover:text-rose-600 rounded-lg transition-colors">
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={5} className="px-6 py-12 text-center text-slate-400 font-semibold">
                        No paired database accounts or credential tokens found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

          </div>
        </main>
      </div>
    </div>
  );
}