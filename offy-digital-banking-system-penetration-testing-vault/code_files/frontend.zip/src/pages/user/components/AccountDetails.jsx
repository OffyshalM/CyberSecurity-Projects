import React from 'react';
import { CreditCard } from "lucide-react";

// Make sure "export default" is explicitly stated here
export default function AccountDetails({ account }) {
  return (
    <div className="space-y-6">
      {/* Plastic Debit Card Layout Graphic */}
      <div className="bg-slate-900 text-white p-6 rounded-2xl shadow-lg relative aspect-[1.586/1] flex flex-col justify-between border border-slate-800">
        <div className="flex justify-between items-start">
          <span className="text-[9px] font-bold tracking-widest text-slate-400 uppercase">Debit Card</span>
          <CreditCard className="h-5 w-5 text-slate-400" />
        </div>
        <div className="text-lg font-mono tracking-widest my-4 text-slate-100">
          4353 4633 5399 ****
        </div>
        <div className="flex justify-between items-end">
          <div>
            <span className="block text-[8px] uppercase tracking-wider text-slate-500">Card Holder</span>
            <span className="text-xs font-bold font-mono text-slate-200 uppercase">
              {account ? account.accountHolder : "Loading..."}
            </span>
          </div>
          <div className="text-right">
            <span className="block text-[8px] uppercase tracking-wider text-slate-500">Expires</span>
            <span className="text-xs font-bold font-mono text-slate-200">06/30</span>
          </div>
        </div>
      </div>

      {/* Account Metadata Detail List */}
      <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">
          Account Details
        </h3>
        <div className="divide-y divide-slate-100 text-xs">
          <div className="py-3 flex justify-between items-center">
            <span className="text-slate-400 font-medium">Account Number</span>
            <span className="font-mono font-bold text-slate-800">
              {account ? account.accountNumber : "***********"}
            </span>
          </div>
          <div className="py-3 flex justify-between items-center">
            <span className="text-slate-400 font-medium">Status</span>
            <span className="text-emerald-700 bg-emerald-50 border border-emerald-100 font-bold px-2.5 py-0.5 rounded-md text-[10px]">
              Verified
            </span>
          </div>
          <div className="py-3 flex justify-between items-center">
            <span className="text-slate-400 font-medium">Branch Code</span>
            <span className="font-mono font-semibold text-slate-600">RBSUS004</span>
          </div>
        </div>
      </div>
    </div>
  );
}