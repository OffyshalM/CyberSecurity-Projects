import React from 'react';
import { Eye } from 'lucide-react';

export default function BalanceCard({ balance, accountType }) {
  return (
    <div className="bg-gradient-to-r from-[#0A2540] via-[#00488F] to-[#0051A2] rounded-3xl p-6 sm:p-8 text-white shadow-xl shadow-blue-900/10 relative overflow-hidden">
      <div className="absolute right-0 top-0 w-48 h-48 bg-white/5 rounded-full blur-3xl pointer-events-none" />
      
      <div className="flex items-center gap-2 mb-2">
        <span className="text-xs uppercase tracking-widest text-blue-200 font-bold block">
          Available Balance
        </span>
        <Eye className="h-3.5 w-3.5 text-blue-300 opacity-70 cursor-pointer" />
      </div>

      <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight mb-2 font-mono">
        ${Number(balance).toLocaleString("en-US", { minimumFractionDigits: 2 })}
      </h1>

    </div>
  );
}