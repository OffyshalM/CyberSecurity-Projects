import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function QuickActions({ icon: Icon, label, color, path }) {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate(path);
  };

  return (
    <button className="bg-white border border-slate-100 p-5 rounded-2xl flex flex-col items-center justify-center text-center gap-3 shadow-sm hover:shadow-md transition-all group w-full" onClick={handleClick}>
      <div className={`p-3 rounded-xl border ${color} transition-transform group-hover:scale-105`}>
        <Icon className="h-5 w-5" />
      </div>
      <span className="text-xs font-bold text-slate-700">{label}</span>
    </button>
  );
}