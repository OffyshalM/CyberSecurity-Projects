import React from 'react';

export default function ActivityCharts() {
  const points = [40, 25, 55, 75, 45, 60, 50];
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

  return (
    <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Account Activity</h3>
        <span className="text-xs font-semibold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-full">Last 7 Days</span>
      </div>
      
      <div className="h-40 w-full flex items-end justify-between pt-4 border-b border-slate-100 px-2">
        {points.map((val, idx) => (
          <div key={idx} className="w-8 flex flex-col items-center gap-2">
            <div 
              className="w-1.5 bg-gradient-to-t from-blue-600 to-blue-400 rounded-t-full transition-all duration-500" 
              style={{ height: `${val * 1.5}px` }} 
            />
            <span className="text-[10px] text-slate-400 font-medium">
              {days[idx]}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}