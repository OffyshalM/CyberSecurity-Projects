import { LayoutDashboard, Landmark, History, CreditCard, Key, ShieldCheck, LogOut } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";

export default function Sidebar() {
  const navigate = useNavigate();
  const location = useLocation();

  const menuGroups = [
    {
      title: "MENU",
      items: [
        { name: "Dashboard", icon: LayoutDashboard, path: "/dashboard" },
      ],
    },
    {
      title: "FUND TRANSFER",
      items: [
        { name: "Bank Transfer", icon: Landmark, path: "/dashboard/transfer" },
        { name: "Transfer History", icon: History, path: "/dashboard/history" },
      ],
    },
    {
      title: "ACCOUNT",
      items: [
        { name: "ATM Card", icon: CreditCard, path: "/dashboard/card" },
        { name: "Transaction Pin", icon: Key, path: "/dashboard/pin" },
        { name: "Account Password", icon: ShieldCheck, path: "/dashboard/password" },
      ],
    },
  ];

  const handleLogout = () => {
    localStorage.clear();
    navigate("/login");
  };

  return (
    <div className="hidden md:flex fixed left-0 top-0 h-screen w-64 flex-col justify-between bg-white border-r border-slate-100 p-6 z-20 text-slate-900">
      <div className="space-y-8">
        {/* Top spacer to align underneath the main top Navbar */}
        <div className="h-16" />

        {/* Dynamic Navigation Link Groups */}
        {menuGroups.map((group, groupIdx) => (
          <div key={groupIdx} className="space-y-2.5">
            <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 px-3">
              {group.title}
            </span>
            <div className="space-y-1">
              {group.items.map((item, itemIdx) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <button
                    key={itemIdx}
                    onClick={() => navigate(item.path)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold tracking-tight transition-all ${
                      isActive
                        ? "bg-blue-50 text-vault-neon font-bold"
                        : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
                    }`}
                  >
                    <Icon className={`h-4 w-4 ${isActive ? "text-vault-neon" : "text-slate-400"}`} />
                    {item.name}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Bottom Fixed Logout Section */}
      <div className="border-t border-slate-100 pt-4">
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold tracking-tight text-red-500 hover:bg-red-50 transition-all"
        >
          <LogOut className="h-4 w-4 text-red-400" />
          Logout
        </button>
      </div>
    </div>
  );
}