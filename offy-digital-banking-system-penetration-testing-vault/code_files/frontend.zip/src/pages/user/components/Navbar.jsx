import React from 'react';
import { Search, Bell, User } from 'lucide-react';

export default function Navbar({ accountHolder }) {
  return (
    <nav className="fixed top-0 left-0 right-0 h-16 bg-white border-b border-slate-100 flex items-center justify-between px-6 z-30">
      {/* Brand Identity */}
      <div className="flex items-center gap-3">
        {/* Neon Green Logo Box */}
        <div className="bg-[#22C55E] p-2 rounded-xl flex items-center justify-center shadow-sm shadow-green-500/20">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="currentColor"
            className="w-4 h-4 text-white"
          >
            <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5v-3l-10 5-10-5v3zm0-5l10 5 10-5V9l-10 5-10-5v3z" />
          </svg>
        </div>
        <span className="font-extrabold text-sm tracking-tight text-slate-900 uppercase">
          Offy Digital Vault
        </span>
      </div>

      {/* Search Bar Input Panel */}
      <div className="hidden sm:flex items-center gap-2 bg-slate-50 border border-slate-100 rounded-full px-4 py-1.5 w-64 transition-all focus-within:border-green-200">
        <Search className="h-3.5 w-3.5 text-slate-400" />
        <input
          type="text"
          placeholder="Type credit or debit..."
          className="bg-transparent text-xs outline-none w-full placeholder:text-slate-400 text-slate-700"
        />
      </div>

      {/* Action Utilities & Avatar Node */}
      <div className="flex items-center gap-4">
        <button className="text-slate-400 hover:text-green-600 transition-colors">
          <Bell className="h-4 w-4" />
        </button>

        <div className="flex items-center gap-2.5 border-l border-slate-100 pl-4">
          <div className="h-8 w-8 bg-slate-100 rounded-full flex items-center justify-center border border-slate-200">
            <User className="h-4 w-4 text-slate-500" />
          </div>
          <div className="text-left hidden md:block">
            <span className="block text-xs font-bold text-slate-800 leading-none">
              {accountHolder || "Loading Profile..."}
            </span>
          </div>
        </div>
      </div>
    </nav>
  );
}