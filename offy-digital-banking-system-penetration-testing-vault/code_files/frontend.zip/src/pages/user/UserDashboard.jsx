import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { 
  Landmark, History, FileText, ShieldAlert,
  UserCircle, Search, Bell, ChevronRight 
} from 'lucide-react';

// Importing your modular child components directly
import Sidebar from './components/Sidebar';
import Navbar from './components/Navbar';
import BalanceCard from './components/BalanceCard';
import QuickActions from './components/QuickActions';
import ActivityChart from './components/ActivityCharts';
import AccountDetails from './components/AccountDetails';

export default function UserDashboard() {
    const navigate = useNavigate();
    const [account, setAccount] = useState(null);
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(true);

    const accountId = localStorage.getItem("currentUserId") || "1";

    useEffect(() => {
        const fetchAccountData = async () => {
            try {
                const API_BASE = `${window.location.origin}/api`;
                const response = await axios.get(`${API_BASE}/accounts/${accountId}`);
                setAccount(response.data);
            } catch (err) {
                setError("Failed to load core banking data from ledger service.");
            } finally {
                setLoading(false);
            }
        };
        fetchAccountData();
    }, [accountId]);


    return (
        <div className="min-h-screen bg-[#F8FAFC] text-slate-900 flex flex-col font-sans">
            {/* Structural Layout Components */}
            <Navbar accountHolder={account?.accountHolder} />
            <Sidebar />

            {/* Main Content Workspace Layout Viewport */}
            <main className="flex-1 md:pl-64 pt-16 overflow-y-auto pb-24">
                <div className="p-4 sm:p-8 max-w-7xl mx-auto space-y-6">

                    {/* ATTACK SURFACE BANNER */}
                    {/* <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3 text-xs text-amber-800 leading-relaxed">
                        <ShieldAlert className="h-4 w-4 text-amber-600 mt-0.5 flex-shrink-0" />
                        <div>
                            <span className="font-bold">Lab Environment Notice:</span> This view maps to 
                            <code className="mx-1 bg-amber-100 px-1 py-0.5 rounded font-mono font-bold text-amber-950">GET /api/accounts/&#123;id&#125;</code>. 
                            Modify your session variables to test the IDOR boundaries.
                        </div>
                    </div> */}

                    {error && (
                        <div className="bg-red-50 border border-red-200 text-xs font-semibold text-red-700 p-4 rounded-xl">
                            {error}
                        </div>
                    )}

                    {/* Core Dashboard Grid Setup */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
                        
                        {/* Left Financial Stream Column */}
                        <div className="lg:col-span-2 space-y-6">
                            <BalanceCard balance={account?.balance || 0} accountType={account?.accountType} />
                            
                            {/* Rendering individual custom quick actions explicitly */}
                            <section className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                                <QuickActions icon={Landmark} label="Transfer" path="/dashboard/transfer" color="text-blue-600 bg-blue-50 border-blue-100" />
                                <QuickActions icon={History} label="History" path="/dashboard/history" color="text-emerald-600 bg-emerald-50 border-emerald-100" />
                                <QuickActions icon={FileText} label="Statement" path="/dashboard/statement" color="text-purple-600 bg-purple-50 border-purple-100" />
                                <QuickActions icon={ShieldAlert} label="Security" path="/dashboard/security" color="text-amber-600 bg-amber-50 border-amber-100" />
                                
                            </section>

                            <ActivityChart />
                        </div>

                        {/* Right Account Information Profile Column */}
                        <div className="space-y-6">
                            <AccountDetails account={account} />

                            {/* Trigger Gateway Routing directly to the Legacy PHP Module */}
                            <button className="w-full bg-white border border-slate-100 rounded-2xl p-4 flex items-center justify-between text-left shadow-sm hover:border-blue-200 transition-all group">
                                <div className="flex items-center gap-3">
                                    <div className="p-2.5 bg-slate-50 border border-slate-100 rounded-xl group-hover:bg-blue-50 group-hover:border-blue-100 transition-colors">
                                        <FileText className="h-4 w-4 text-slate-500 group-hover:text-blue-600" />
                                    </div>
                                    <div>
                                        <span className="block text-xs font-bold text-slate-800">Legacy Ticket Support</span>
                                        <span className="text-[10px] text-slate-400 block mt-0.5">Search internal archived complaint logs</span>
                                    </div>
                                </div>
                                <ChevronRight className="h-4 w-4 text-slate-300 group-hover:text-blue-500 transition-transform group-hover:translate-x-0.5" />
                            </button>
                        </div>

                    </div>

                </div>
            </main>
        </div>
    );
}