import React, { useState, useEffect } from "react";
import { ArrowUpDown, Loader2, Search } from "lucide-react";
import Sidebar from "./components/Sidebar";
import Navbar from "./components/Navbar";

export default function TransferHistory() {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  
  // Search & Pagination States
  const [searchTerm, setSearchTerm] = useState("");
  const [entriesPerPage, setEntriesPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(1);

  // User Profile Name State
  const [accountHolder, setAccountHolder] = useState("Okunrobo Moses Emmanuel");

  const API_BASE = `${window.location.origin}/api`;
  const activeAccountNumber = 
    localStorage.getItem("account_number") || 
    localStorage.getItem("accountNumber") || 
    "1002003002";

  const accountId = localStorage.getItem("currentUserId") || "1";

  // Fetch account profile details for Navbar context
  const fetchProfile = async () => {
    try {
      const res = await fetch(`${API_BASE}/accounts/${accountId}`);
      if (res.ok) {
        const data = await res.json();
        if (data.accountHolder) {
          setAccountHolder(data.accountHolder);
        }
      }
    } catch (err) {
      console.error("Failed to load profile context:", err);
    }
  };

  // Fetch transaction history
  const fetchTransactions = async () => {
    setLoading(true);
    setError("");
    
    // Perfect match with com.offy.vault.controller.TransactionController
    const url = `${API_BASE}/transactions/transfer/history/${activeAccountNumber}`;

    try {
      const response = await fetch(url, {
        method: "GET",
        headers: { "Content-Type": "application/json" }
      });

      if (response.ok) {
        const text = await response.text();
        
        try {
          // If the backend returned JSON data array, parse it
          const data = JSON.parse(text);
          setTransactions(Array.isArray(data) ? data : []);
        } catch (jsonError) {
          // If parsing fails, backend returned the string "No tranactions found..."
          setTransactions([]);
        }
      } else {
        setError("Failed to retrieve transaction logs from database.");
      }
    } catch (err) {
      setError("Unable to connect to the server. Please verify your backend is running on port 8081.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
    if (activeAccountNumber) {
      fetchTransactions();
    }
  }, [activeAccountNumber]);

  // Filtered transactions based on search input
  const filteredTransactions = transactions.filter((tx) => {
    const sTerm = searchTerm.toLowerCase();
    const txId = String(tx.id || "").toLowerCase();
    const beneficiary = String(tx.receiverName || tx.receiverAccountNumber || "").toLowerCase();
    const bank = String(tx.bankName || "").toLowerCase();
    const amount = String(tx.amount || "").toLowerCase();
    
    return (
      txId.includes(sTerm) ||
      beneficiary.includes(sTerm) ||
      bank.includes(sTerm) ||
      amount.includes(sTerm)
    );
  });

  // Pagination Logic
  const indexOfLastEntry = currentPage * entriesPerPage;
  const indexOfFirstEntry = indexOfLastEntry - entriesPerPage;
  const currentEntries = filteredTransactions.slice(indexOfFirstEntry, indexOfLastEntry);
  const totalPages = Math.ceil(filteredTransactions.length / entriesPerPage);

  const handlePrevPage = () => {
    if (currentPage > 1) setCurrentPage(currentPage - 1);
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) setCurrentPage(currentPage + 1);
  };

  const formatDate = (timestamp) => {
    if (!timestamp) return "Pending";
    const date = new Date(timestamp);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-800 font-sans animate-fadeIn" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      {/* PERSISTENT SIDEBAR */}
      <Sidebar />

      {/* MAIN CONTENT AREA */}
      <div className="flex-1 flex flex-col min-w-0 md:pl-64">
        {/* PERSISTENT TOP NAVBAR */}
        <Navbar accountHolder={accountHolder} />

        {/* WORKSPACE AREA */}
        <main className="p-4 sm:p-8 max-w-7xl w-full mx-auto space-y-6 pt-20">
          
          {/* Section Header */}
          <div className="space-y-1">
            <h1 className="text-2xl font-bold text-slate-800 tracking-tight">Transfer History</h1>
            <p className="text-xs text-slate-400">Swipe left/right to view full table on mobile.</p>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 text-xs font-semibold text-red-700 p-4 rounded-xl">
              {error}
            </div>
          )}

          {/* TABLE PANEL CONTAINER */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 space-y-4">
            
            {/* Table Controller Header Controls */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              
              {/* Show Entries Dropdown */}
              <div className="flex items-center gap-2 text-sm text-slate-500 font-medium">
                <span>Show</span>
                <select
                  value={entriesPerPage}
                  onChange={(e) => {
                    setEntriesPerPage(Number(e.target.value));
                    setCurrentPage(1);
                  }}
                  className="border border-slate-200 rounded-lg px-2.5 py-1 text-sm bg-white outline-none focus:border-blue-500 font-semibold"
                >
                  <option value={5}>5</option>
                  <option value={10}>10</option>
                  <option value={25}>25</option>
                  <option value={50}>50</option>
                </select>
                <span>entries</span>
              </div>

              {/* Search Field */}
              <div className="relative w-full sm:max-w-xs">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 h-4 w-4" />
                <input
                  type="text"
                  placeholder="Search history..."
                  value={searchTerm}
                  onChange={(e) => {
                    setSearchTerm(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="w-full border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-xs bg-white outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all"
                />
              </div>
            </div>

            {/* RESPONSIVE SCROLLABLE DATA TABLE CONTAINER */}
            <div className="overflow-x-auto border border-slate-100 rounded-xl">
              <table className="w-full text-left border-collapse min-w-[700px]">
                <thead>
                  <tr className="bg-[#f8fafc] border-b border-slate-100 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                    <th className="px-6 py-4">
                      <div className="flex items-center gap-1.5 cursor-pointer hover:text-slate-700">
                        TRANSACTION ID <ArrowUpDown className="h-3 w-3" />
                      </div>
                    </th>
                    <th className="px-6 py-4">
                      <div className="flex items-center gap-1.5 cursor-pointer hover:text-slate-700">
                        DATE <ArrowUpDown className="h-3 w-3" />
                      </div>
                    </th>
                    <th className="px-6 py-4">
                      <div className="flex items-center gap-1.5 cursor-pointer hover:text-slate-700">
                        BENEFICIARY <ArrowUpDown className="h-3 w-3" />
                      </div>
                    </th>
                    <th className="px-6 py-4">
                      <div className="flex items-center gap-1.5 cursor-pointer hover:text-slate-700">
                        BANK <ArrowUpDown className="h-3 w-3" />
                      </div>
                    </th>
                    <th className="px-6 py-4">
                      <div className="flex items-center gap-1.5 cursor-pointer hover:text-slate-700">
                        AMOUNT <ArrowUpDown className="h-3 w-3" />
                      </div>
                    </th>
                    <th className="px-6 py-4">
                      <div className="flex items-center gap-1.5 cursor-pointer hover:text-slate-700">
                        STATUS <ArrowUpDown className="h-3 w-3" />
                      </div>
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs text-slate-600 font-medium">
                  {loading ? (
                    <tr>
                      <td colSpan={6} className="px-6 py-12 text-center">
                        <div className="flex items-center justify-center gap-2 text-slate-400">
                          <Loader2 className="h-5 w-5 animate-spin text-blue-500" />
                          <span>Syncing with secure transaction ledger...</span>
                        </div>
                      </td>
                    </tr>
                  ) : currentEntries.length > 0 ? (
                    currentEntries.map((tx) => (
                      <tr key={tx.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="px-6 py-4 font-semibold text-slate-700">
                          TX-{tx.id || "0000"}
                        </td>
                        <td className="px-6 py-4 text-slate-400">
                          {formatDate(tx.timestamp)}
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex flex-col">
                            <span className="font-bold text-slate-700">{tx.receiverName || "Unknown"}</span>
                            <span className="text-[10px] text-slate-400 mt-0.5">{tx.receiverAccountNumber || "N/A"}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-slate-500">
                          {tx.bankName || "Transfer Link"}
                        </td>
                        <td className="px-6 py-4 font-bold text-slate-700">
                          ${Math.abs(tx.amount).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                        <td className="px-6 py-4">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-600 border border-emerald-100">
                            Successful
                          </span>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={6} className="px-6 py-12 text-center text-slate-400 font-semibold">
                        No data available in table
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* PAGINATION FOOTER */}
            {!loading && filteredTransactions.length > 0 && (
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-100">
                <span className="text-xs text-slate-400 font-medium">
                  Showing {indexOfFirstEntry + 1} to {Math.min(indexOfLastEntry, filteredTransactions.length)} of {filteredTransactions.length} entries
                </span>
                
                <div className="flex items-center gap-1">
                  <button
                    onClick={handlePrevPage}
                    disabled={currentPage === 1}
                    className="px-4 py-2 border border-slate-200 text-xs rounded-xl font-bold hover:bg-slate-50 transition-all disabled:opacity-40 disabled:hover:bg-transparent text-slate-500"
                  >
                    Previous
                  </button>
                  <button
                    onClick={handleNextPage}
                    disabled={currentPage === totalPages}
                    className="px-4 py-2 border border-slate-200 text-xs rounded-xl font-bold hover:bg-slate-50 transition-all disabled:opacity-40 disabled:hover:bg-transparent text-slate-500"
                  >
                    Next
                  </button>
                </div>
              </div>
            )}

          </div>
        </main>
      </div>
    </div>
  );
}