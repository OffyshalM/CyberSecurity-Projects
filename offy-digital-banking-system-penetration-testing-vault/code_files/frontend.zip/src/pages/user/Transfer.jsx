import React, { useState, useEffect } from "react";
import { CheckCircle2, XCircle, Loader2 } from "lucide-react";
import Sidebar from "./components/Sidebar";
import Navbar from "./components/Navbar";

export default function Transfer() {
  const [bankName, setBankName] = useState("");
  const [bankAddress, setBankAddress] = useState("");
  const [receiverName, setReceiverName] = useState("");
  const [receiverAccount, setReceiverAccount] = useState("");
  const [amount, setAmount] = useState("");
  const [pin, setPin] = useState("");
  
  const [transferLoading, setTransferLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [modalData, setModalData] = useState({ success: true, message: "" });
  
  const activeAccountNumber = 
    localStorage.getItem("account_number") || 
    localStorage.getItem("accountNumber") || 
    "1002003002";

  const accountId = localStorage.getItem("currentUserId") || "1";

  const [account, setAccount] = useState({
    accountHolder: "",
    accountNumber: activeAccountNumber,
  });

const API_BASE = `${window.location.origin}/api`;
  const fetchAccountData = async () => {
    try {
      const response = await fetch(`${API_BASE}/accounts/${accountId}`);
      if (response.ok) {
        const data = await response.json();
        setAccount(prev => ({
          ...prev,
          accountHolder: data.accountHolder || "Okunrobo Moses Emmanuel",
          accountNumber: data.accountNumber || activeAccountNumber
        }));
      } else {
        setAccount(prev => ({
          ...prev,
          accountHolder: "Okunrobo Moses Emmanuel",
        }));
      }
    } catch (error) {
      setAccount(prev => ({
        ...prev,
        accountHolder: "Okunrobo Moses Emmanuel",
      }));
    }
  };

  useEffect(() => {
    if (accountId) {
      fetchAccountData();
    }
  }, [accountId]);

  const handleTransfer = async (e) => {
    e.preventDefault();
    setTransferLoading(true);

    const payload = {
      senderAccountNumber: account.accountNumber,
      receiverAccountNumber: receiverAccount,
      amount: parseFloat(amount),
      pin: pin,
      bankName: bankName,
      bankAddress: bankAddress,
      receiverName: receiverName
    };

    try {
      const response = await fetch(`${API_BASE}/transactions/transfer/`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const text = await response.text();

      if (response.ok) {
        setModalData({
          success: true,
          message: text || "Your transaction was completed successfully.",
        });
        setReceiverAccount("");
        setAmount("");
        setPin("");
        setBankName("");
        setBankAddress("");
        setReceiverName("");
        
        await fetchAccountData();
      } else {
        setModalData({
          success: false,
          message: text || "Transaction failed. Please check your details and try again.",
        });
      }
    } catch (error) {
      setModalData({
        success: false,
        message: "Unable to connect to the server. Please check if your backend is running.",
      });
    } finally {
      setTransferLoading(false);
      setShowModal(true);
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-800 font-sans" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      {/* PERSISTENT SIDEBAR */}
      <Sidebar />

      {/* MAIN CONTENT AREA */}
      <div className="flex-1 flex flex-col min-w-0 md:pl-64">
        {/* PERSISTENT TOP NAVBAR */}
        <Navbar accountHolder={account.accountHolder || "Okunrobo Moses Emmanuel"} />

        {/* WORKSPACE AREA */}
        <main className="p-6 md:p-8 max-w-6xl w-full mx-auto space-y-6">
          {/* Breadcrumb & Section Header */}
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-xl font-bold text-slate-800 tracking-tight">International Transfer</h1>
            </div>
            <div className="text-xs text-slate-400">
              Dashboard / <span className="text-[#1e5ecb] font-medium">Transfer</span>
            </div>
          </div>

          {/* MAIN FORM PANEL */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 md:p-8">
            <form onSubmit={handleTransfer} className="space-y-6">
              
              {/* Receiver's Bank Name */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2">Receiver's Bank Name</label>
                <input 
                  type="text" 
                  required
                  placeholder="Enter receiver's financial institution" 
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  className="w-full border border-slate-200 rounded-xl px-4 py-3 text-xs focus:ring-1 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                />
              </div>

              {/* Grid 1: Bank Address & Receiver's Name */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-2">Bank Address</label>
                  <input 
                    type="text" 
                    required
                    placeholder="Physical branch address" 
                    value={bankAddress}
                    onChange={(e) => setBankAddress(e.target.value)}
                    className="w-full border border-slate-200 rounded-xl px-4 py-3 text-xs focus:ring-1 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-2">Receiver's Name</label>
                  <input 
                    type="text" 
                    required
                    placeholder="Full legal name of beneficiary" 
                    value={receiverName}
                    onChange={(e) => setReceiverName(e.target.value)}
                    className="w-full border border-slate-200 rounded-xl px-4 py-3 text-xs focus:ring-1 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                  />
                </div>
              </div>

              {/* Grid 2: Account Number & Amount */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-2">Account Number</label>
                  <input 
                    type="text" 
                    required
                    placeholder="Enter account number" 
                    value={receiverAccount}
                    onChange={(e) => setReceiverAccount(e.target.value)}
                    className="w-full border border-slate-200 rounded-xl px-4 py-3 text-xs focus:ring-1 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-2">Amount To Transfer</label>
                  <input 
                    type="number" 
                    step="any"
                    required
                    placeholder="0.00" 
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full border border-slate-200 rounded-xl px-4 py-3 text-xs focus:ring-1 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                  />
                </div>
              </div>

              {/* Grid 3: PIN Input & Source Account Indicator */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-2">Transaction PIN</label>
                  <input 
                    type="password" 
                    maxLength={4}
                    required
                    placeholder="••••" 
                    value={pin}
                    onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))}
                    className="w-full border border-slate-200 rounded-xl px-4 py-3 text-xs focus:ring-1 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all tracking-widest"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-2">Debit From Account</label>
                  <div className="w-full bg-slate-50 border border-slate-100 text-slate-500 rounded-xl px-4 py-3 text-xs font-semibold flex items-center justify-between">
                    <span>{account.accountNumber}</span>
                    <span className="text-[10px] text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">Active</span>
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-4">
                <button
                  type="submit"
                  disabled={transferLoading}
                  className="w-full bg-vault-neon hover:bg-vault-hover text-white text-xs font-bold py-4 px-6 rounded-xl transition-all shadow-md flex justify-center items-center gap-2 disabled:opacity-50"
                >
                  {transferLoading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Processing Transfer...
                    </>
                  ) : (
                    "Proceed Transfer"
                  )}
                </button>
              </div>
            </form>
          </div>
        </main>
      </div>

      {/* POPUP MODAL */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40">
          <div className="bg-white w-full max-w-lg rounded-3xl p-10 shadow-2xl flex flex-col items-center text-center space-y-6">
            
            {/* Visual Checkmark Wrapper */}
            {modalData.success ? (
              <div className="h-24 w-24 rounded-full border-[3px] border-emerald-100 bg-[#f4fbf7] flex items-center justify-center">
                <svg className="h-10 w-10 text-emerald-500" fill="none" stroke="currentColor" strokeWidth="3" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
              </div>
            ) : (
              <div className="h-24 w-24 rounded-full border-[3px] border-red-100 bg-red-50 flex items-center justify-center">
                <XCircle className="h-10 w-10 text-red-500" />
              </div>
            )}

            {/* Typography */}
            <div className="space-y-3">
              <h3 className="text-3xl font-semibold text-slate-800 tracking-tight">
                {modalData.success ? "Transaction Successful" : "Failed!"}
              </h3>
              <p className="text-sm text-slate-500 font-medium max-w-md mx-auto leading-relaxed">
                {modalData.success ? "Transfer completed successfully." : modalData.message}
              </p>
            </div>

            {/* Action Button */}
            <div className="pt-2 w-full max-w-[120px]">
              <button
                onClick={() => setShowModal(false)}
                className="w-full bg-vault-neon hover:bg-vault-hover text-white text-sm font-semibold py-2.5 px-6 rounded-xl transition-all shadow-md flex justify-center items-center"
              >
                OK
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}