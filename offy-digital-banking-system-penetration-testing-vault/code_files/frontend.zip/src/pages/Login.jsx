// src/pages/Login.jsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { Vault, User, Lock, Shield, CheckCircle, Smartphone, AlertCircle, Loader2, CreditCard } from "lucide-react";

export default function Login() {
  const [step, setStep] = useState(1); // 1 = Credentials, 2 = 6-Digit Code
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [otp, setOtp] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  // Handle Step 1: Initial Login Credentials
  const handleCredentialsSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const API_BASE = `${window.location.origin}/api`;
      const response = await axios.post(`${API_BASE}/users/login`, {
        username: username,
        password: password
      });

      if (response.data) {
        localStorage.setItem("currentUserId", response.data.id);
        localStorage.setItem("username", response.data.username);
        localStorage.setItem("role", response.data.role);
        localStorage.setItem("accountNumber", response.data.accountNumber);
        
        setStep(2); // Advance to OTP verification
      }
    } catch (err) {
      if (err.response && err.response.data) {
        setError(err.response.data);
      } else {
        setError("Invalid username/password");
      }
    } finally {
      setLoading(false);
    }
  };

  // Handle Step 2: 6-Digit MFA Code Verification
  const handleOtpSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    // Intentional Weak Code verification check for the lab environment
    if (otp === "123456" || otp.length === 6) { 
      const role = localStorage.getItem("role");
      if (role === "ADMIN") {
        navigate("/admin/dashboard");
      } else {
        navigate("/dashboard");
      }
    } else {
      setError("Invalid 6-digit verification code.");
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-vault-bg font-sans">
      
      {/* LEFT PANE: Dark Branding Showcase Panel */}
      <div className="hidden lg:flex w-1/2 flex-col justify-between bg-gradient-to-br from-vault-card to-vault-bg p-12 border-r border-vault-border text-vault-text-main">
        <div className="flex items-center gap-3">
          <Vault className="h-8 w-8 text-vault-neon" />
          <span className="text-xl font-bold tracking-wide">Offy Digital Vault</span>
        </div>

        <div className="max-w-md space-y-6">
          <h1 className="text-4xl font-extrabold tracking-tight leading-tight">
            Unified Control Center for Infrastructure Operations.
          </h1>
          <p className="text-vault-text-muted leading-relaxed text-sm">
            Monitor real-time data feeds, manage assets, and audit core platform metrics from a single secure interface.
          </p>
          
          <div className="space-y-4 pt-4">
            <div className="flex items-center gap-3 bg-vault-card/40 border border-vault-border/60 p-3 rounded-xl">
              <Shield className="h-5 w-5 text-vault-neon" />
              <span className="text-sm font-medium">Bank-Level Isolation Architecture</span>
            </div>
            <div className="flex items-center gap-3 bg-vault-card/40 border border-vault-border/60 p-3 rounded-xl">
              <CheckCircle className="h-5 w-5 text-vault-neon" />
              <span className="text-sm font-medium">Multi-Factor Token Handshake</span>
            </div>
            <div className="flex items-center gap-3 bg-vault-card/40 border border-vault-border/60 p-3 rounded-xl">
              <CreditCard className="h-5 w-5 text-vault-neon" />
              <span className="text-sm font-medium">Real-Time Core Banking Settlement</span>
            </div>
          </div>
        </div>

        <div className="text-xs text-vault-text-muted">
          © 2026 Offy Digital Vault Inc. All rights reserved.
        </div>
      </div>

      {/* RIGHT PANE: Solid White Form Panel with Vault Green Accent Buttons */}
      <div className="w-full lg:w-1/2 flex flex-col justify-center items-center p-6 sm:p-12 bg-white text-slate-900">
        <div className="w-full max-w-md">
          
          {/* Header Block */}
          <div className="mb-6">
            <h2 className="text-3xl font-extrabold tracking-tight text-slate-950">
              Sign In
            </h2>
            <p className="text-sm text-slate-500 mt-1">
              Enter your details to access your account.
            </p>
          </div>

          {/* STEP PROGRESS TRACKER NODE BAR */}
          <div className="flex items-center justify-start gap-4 mb-8">
            {/* Step 1 Node */}
            <div className={`flex h-9 w-9 items-center justify-center rounded-full text-xs font-bold transition-all duration-300 ${
              step === 1 
                ? "bg-slate-950 text-white ring-4 ring-slate-100" 
                : "bg-vault-neon text-slate-950"
            }`}>
              {step > 1 ? "✓" : "1"}
            </div>
            
            {/* Connecting Bridge Line */}
            <div className={`h-0.5 w-12 transition-all duration-300 ${
              step === 2 ? "bg-vault-neon" : "bg-slate-200"
            }`} />
            
            {/* Step 2 Node */}
            <div className={`flex h-9 w-9 items-center justify-center rounded-full text-xs font-bold transition-all duration-300 ${
              step === 2 
                ? "bg-slate-950 text-white ring-4 ring-slate-100" 
                : "bg-slate-100 text-slate-400"
            }`}>
              2
            </div>
          </div>

          {/* Error Notification Banner (The Red Stuff) */}
          {error && (
            <div className="mb-6 flex items-center gap-2 rounded-xl bg-red-50 border border-red-200 p-4 text-sm text-red-600 font-medium">
              <AlertCircle className="h-4 w-4 flex-shrink-0 text-red-500" />
              <span>{error}</span>
            </div>
          )}

          {/* STEP 1: INITIAL CREDENTIALS ENTRY */}
          {step === 1 && (
            <form onSubmit={handleCredentialsSubmit} className="space-y-5">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Username
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Enter username"
                    className="w-full rounded-xl border border-slate-200 bg-slate-50/50 py-3 pl-10 pr-4 text-sm text-slate-900 placeholder:text-slate-400 focus:border-slate-950 focus:bg-white focus:outline-none transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full rounded-xl border border-slate-200 bg-slate-50/50 py-3 pl-10 pr-4 text-sm text-slate-900 placeholder:text-slate-400 focus:border-slate-950 focus:bg-white focus:outline-none transition-all"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full mt-2 rounded-xl bg-vault-neon py-3 text-sm font-bold text-slate-950 shadow-md hover:bg-vault-mint active:scale-[0.98] disabled:opacity-50 transition-all flex items-center justify-center gap-2"
              >
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Login"}
              </button>
            </form>
          )}

          {/* STEP 2: 6-DIGIT MULTI-FACTOR CHALLENGE */}
          {step === 2 && (
            <form onSubmit={handleOtpSubmit} className="space-y-5">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  6-Digit Verification Code
                </label>
                <div className="relative">
                  <Smartphone className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    maxLength={6}
                    required
                    pattern="\d{6}"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))}
                    placeholder="000000"
                    className="w-full text-center tracking-[0.5em] font-mono rounded-xl border border-slate-200 bg-slate-50/50 py-3 pl-10 pr-4 text-lg text-slate-900 focus:border-slate-950 focus:bg-white focus:outline-none transition-all"
                  />
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="w-1/3 rounded-xl border border-slate-200 py-3 text-xs font-semibold text-slate-500 hover:bg-slate-50 hover:text-slate-800 transition-all"
                >
                  Back
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="w-2/3 rounded-xl bg-vault-neon py-3 text-xs font-bold text-slate-950 shadow-md hover:bg-vault-mint transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Verify & Authorize"}
                </button>
              </div>
            </form>
          )}

        </div>
      </div>
    </div>
  );
}