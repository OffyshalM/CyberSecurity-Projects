// src/App.jsx
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login";
import UserDashboard from "./pages/user/UserDashboard";
import AdminLogin from "./pages/admin/AdminLogin";
import AdminDashboard from "./pages/admin/AdminDashboard";
import Transfer from "./pages/user/Transfer";
import TransactionHistory from "./pages/user/TransactionHistory";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* --- CLIENT / USER ROUTES --- */}
        {/* http://localhost:5173/login */}
        <Route path="/login" element={<Login />} />
        
        {/* http://localhost:5173/dashboard */}
        <Route path="/dashboard" element={<UserDashboard />} />

        <Route path="/dashboard/transfer" element={<Transfer/>} />
        <Route path="/dashboard/history" element={<TransactionHistory />} />

        {/* --- ADMINISTRATIVE ROUTES --- */}
        {/* http://localhost:5173/admin/login */}
        <Route path="/admin/login" element={<AdminLogin />} />
        
        {/* http://localhost:5173/admin/dashboard */}
        <Route path="/admin/dashboard" element={<AdminDashboard />} />


        {/* --- GLOBAL FALLBACK --- */}
        {/* If a user types a broken URL, automatically redirect them to the client login */}
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </BrowserRouter>
  );
}